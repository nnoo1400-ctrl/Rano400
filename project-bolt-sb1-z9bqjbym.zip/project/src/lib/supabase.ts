import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type TransferIn = {
  id: string;
  student_name: string;
  national_id: string;
  grade: string;
  section: string;
  from_school: string;
  transfer_date: string;
  start_date: string;
  notes: string;
  created_at: string;
};

export type TransferOut = {
  id: string;
  student_name: string;
  national_id: string;
  grade: string;
  section: string;
  to_school: string;
  transfer_date: string;
  notes: string;
  created_at: string;
};

export type ElearningStudent = {
  id: string;
  student_name: string;
  national_id: string;
  grade: string;
  section: string;
  transfer_date: string;
  notes: string;
  created_at: string;
};
