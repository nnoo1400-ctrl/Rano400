/*
  # إضافة جدول طالبات التعليم الإلكتروني

  ## الجداول الجديدة:
  - `elearning_students`: سجل طالبات التعليم عن بعد
    - الاسم، رقم الهوية، المرحلة الدراسية، الفصل
    - تاريخ التحويل إلى التعليم الإلكتروني
    - ملاحظات

  ## الأمان:
  - تفعيل RLS
  - وصول كامل للمستخدمين المصادق عليهم
*/

CREATE TABLE IF NOT EXISTS elearning_students (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  student_name text NOT NULL,
  national_id text NOT NULL,
  grade text NOT NULL,
  section text DEFAULT '',
  transfer_date date NOT NULL,
  notes text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE elearning_students ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can select elearning_students"
  ON elearning_students FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can insert elearning_students"
  ON elearning_students FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update elearning_students"
  ON elearning_students FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Authenticated users can delete elearning_students"
  ON elearning_students FOR DELETE
  TO authenticated
  USING (true);
