/*
  # Allow anonymous access to registry tables

  This migration adds RLS policies to allow unauthenticated (anon) users
  to perform full CRUD operations on the three registry tables:
  - transfers_in
  - transfers_out
  - elearning_students

  This is appropriate for an internal school registry tool that does not
  require user authentication.
*/

-- transfers_in
CREATE POLICY "Public can select transfers_in"
  ON transfers_in FOR SELECT
  TO anon
  USING (true);

CREATE POLICY "Public can insert transfers_in"
  ON transfers_in FOR INSERT
  TO anon
  WITH CHECK (true);

CREATE POLICY "Public can update transfers_in"
  ON transfers_in FOR UPDATE
  TO anon
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Public can delete transfers_in"
  ON transfers_in FOR DELETE
  TO anon
  USING (true);

-- transfers_out
CREATE POLICY "Public can select transfers_out"
  ON transfers_out FOR SELECT
  TO anon
  USING (true);

CREATE POLICY "Public can insert transfers_out"
  ON transfers_out FOR INSERT
  TO anon
  WITH CHECK (true);

CREATE POLICY "Public can update transfers_out"
  ON transfers_out FOR UPDATE
  TO anon
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Public can delete transfers_out"
  ON transfers_out FOR DELETE
  TO anon
  USING (true);

-- elearning_students
CREATE POLICY "Public can select elearning_students"
  ON elearning_students FOR SELECT
  TO anon
  USING (true);

CREATE POLICY "Public can insert elearning_students"
  ON elearning_students FOR INSERT
  TO anon
  WITH CHECK (true);

CREATE POLICY "Public can update elearning_students"
  ON elearning_students FOR UPDATE
  TO anon
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Public can delete elearning_students"
  ON elearning_students FOR DELETE
  TO anon
  USING (true);
