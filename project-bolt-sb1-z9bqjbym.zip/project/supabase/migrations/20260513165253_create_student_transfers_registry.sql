/*
  # سجل التسجيل والقبول - نقل الطالبات

  ## الجداول الجديدة:
  - `students`: بيانات الطالبات الأساسية
    - الاسم، رقم الهوية، المرحلة الدراسية، الفصل
  - `transfers_in`: سجل الطالبات المنقولات إلى المدرسة
    - المدرسة المنقولة منها، تاريخ النقل، تاريخ المباشرة
  - `transfers_out`: سجل الطالبات المنقولات من المدرسة
    - المدرسة المنقولة إليها، تاريخ النقل

  ## الأمان:
  - تفعيل RLS على جميع الجداول
  - السياسات: وصول كامل للمستخدمين المصادق عليهم
*/

-- جدول الطالبات
CREATE TABLE IF NOT EXISTS students (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  national_id text UNIQUE NOT NULL,
  grade text NOT NULL, -- المرحلة: أول ثانوي / ثاني ثانوي / ثالث ثانوي
  section text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE students ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can select students"
  ON students FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can insert students"
  ON students FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update students"
  ON students FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Authenticated users can delete students"
  ON students FOR DELETE
  TO authenticated
  USING (true);

-- جدول الطالبات المنقولات إلى المدرسة
CREATE TABLE IF NOT EXISTS transfers_in (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  student_name text NOT NULL,
  national_id text NOT NULL,
  grade text NOT NULL,
  section text DEFAULT '',
  from_school text NOT NULL,
  transfer_date date NOT NULL,
  start_date date NOT NULL,
  notes text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE transfers_in ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can select transfers_in"
  ON transfers_in FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can insert transfers_in"
  ON transfers_in FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update transfers_in"
  ON transfers_in FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Authenticated users can delete transfers_in"
  ON transfers_in FOR DELETE
  TO authenticated
  USING (true);

-- جدول الطالبات المنقولات من المدرسة
CREATE TABLE IF NOT EXISTS transfers_out (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  student_name text NOT NULL,
  national_id text NOT NULL,
  grade text NOT NULL,
  section text DEFAULT '',
  to_school text NOT NULL,
  transfer_date date NOT NULL,
  notes text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE transfers_out ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can select transfers_out"
  ON transfers_out FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can insert transfers_out"
  ON transfers_out FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update transfers_out"
  ON transfers_out FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Authenticated users can delete transfers_out"
  ON transfers_out FOR DELETE
  TO authenticated
  USING (true);
